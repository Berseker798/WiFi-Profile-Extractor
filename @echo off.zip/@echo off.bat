@echo off
:: Ustawienie folderu roboczego na ten, w którym jest plik .bat
set "logdir=%~dp0hasla_wifi"
if not exist "%logdir%" mkdir "%logdir%"

echo Trwa wyciaganie hasel...

:: Pobranie listy profili sieciowych
for /f "tokens=4 delims=: " %%i in ('netsh wlan show profiles ^| findstr "All User Profile"') do (
    :: Wyciagniecie hasla dla kazdego profilu
    netsh wlan show profile name="%%i" key=clear > "%logdir%\%%i.txt"
)

echo Gotowe! Hasla sa w folderze: %logdir%
pause